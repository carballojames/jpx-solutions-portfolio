'use client'

import Image from 'next/image'
import { useEffect, useState } from 'react'
import { ArrowUpRight, Link2, Mail, MapPin, Menu, X } from 'lucide-react'
import { portfolioData } from '@/src/data/portfolio'

const nav = ['about', 'projects', 'services', 'contact'] as const

export default function PortfolioBook() {
  const [active, setActive] = useState('about')
  const [menuOpen, setMenuOpen] = useState(false)
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0]
      if (visible) setActive(visible.target.id)
    }, { rootMargin: '-30% 0px -55% 0px', threshold: [0.2, 0.5] })
    nav.forEach((id) => { const node = document.getElementById(id); if (node) observer.observe(node) })
    return () => observer.disconnect()
  }, [])
  const go = (id: string) => { document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' }); setMenuOpen(false) }
  return (
    <main className="portfolio-shell">
      <div className="paper-noise" aria-hidden="true" />
      <header className="site-header"><a className="wordmark" href="#about">JPX<span>.</span></a><nav className="desktop-nav" aria-label="Primary navigation">{nav.map((id, i) => <button key={id} className={active === id ? 'active' : ''} onClick={() => go(id)}><span>0{i + 1}</span>{id}</button>)}</nav><button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation" aria-expanded={menuOpen}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button></header>
      {menuOpen && <nav className="mobile-nav">{nav.map((id, i) => <button key={id} onClick={() => go(id)}><span>0{i + 1}</span>{id}</button>)}</nav>}
      <div className="book-progress"><span style={{ height: `${(nav.indexOf(active as typeof nav[number]) + 1) * 25}%` }} /></div>
      <div className="book-content">
        <section id="about" className="book-page"><div className="page-inner"><p className="eyebrow">Curriculum Vitae / Portfolio</p><div className="resume-top"><h1>{portfolioData.profile.firstName} {portfolioData.profile.lastName}<br />{portfolioData.profile.surname}</h1><span>Davao / PH</span></div><div className="about-grid"><div><div className="page-number"><span>01</span><i />About me</div><h2 className="hero-title">Building digital tools that make work feel <em>simpler.</em></h2><p className="hero-copy">{portfolioData.profile.bio}</p><div className="hero-actions"><a className="dark-button" href="#projects">View selected work <ArrowUpRight size={14} /></a><span className="availability"><b />{portfolioData.profile.availability}</span></div></div><aside className="about-aside"><div className="photo-card"><div className="photo-card-image"><Image src="/images/jpx-photo-card.png" alt="Portrait of James Paul U. Carballo" fill priority sizes="(max-width: 800px) 100vw, 360px" /></div><div className="photo-card-caption"><strong>James Paul U. Carballo</strong><span>Full-stack developer</span><small>Davao City, Philippines</small></div></div><p>An engineer with a designer&apos;s eye for clear systems, considered interfaces, and useful details.</p><div className="aside-meta">Based in Davao City<br />Working worldwide / remotely</div></aside></div><div className="profile-grid"><div><p className="section-kicker">01 / Profile</p><p className="muted-copy">I care about the space between a great idea and a dependable product: the architecture, interface, and small decisions that help people do their best work.</p><p className="meta-line"><MapPin size={13} />{portfolioData.profile.location}</p></div><div className="skills-grid">{Object.entries(portfolioData.skills).map(([key, items]) => <div key={key}><h3>{key}</h3><p>{items.join(' / ')}</p></div>)}</div></div></div></section>
        <section id="projects" className="book-page"><div className="page-inner"><div className="section-header"><div className="page-number"><span>02</span><i />Selected work</div><div className="header-row"><h2>Projects with a purpose.</h2><p>A selection of systems, tools, and digital products built to solve real problems.</p></div></div>{portfolioData.projects.map((project) => <article className="project-card" key={project.id}><div className="project-row"><span className="project-number">PROJECT {project.number}</span><div><h3>{project.title}</h3><p>{project.category}</p></div><p className="project-description">{project.description}</p><ArrowUpRight className="project-arrow" size={20} /></div><div className="project-tags"><span>{project.year}</span>{project.technologies.slice(0, 4).map((tech) => <span key={tech}>{tech}</span>)}</div></article>)}</div></section>
        <section id="services" className="book-page"><div className="page-inner"><div className="section-header"><div className="page-number"><span>03</span><i />Services</div><div className="header-row"><h2>Built around your needs.</h2><p>Development services for individuals, businesses, and growing teams.</p></div></div>{portfolioData.services.map((service, i) => <article className="service-row" key={service.id}><span className="service-number">0{i + 1}</span><div><h3>{service.name}</h3><p>{service.description}</p></div><div className="service-details"><div><p className="section-kicker">Engagement</p><strong>Tailored scope</strong><span>{service.timeline}</span></div><ul>{service.features.slice(0, 6).map((feature) => <li key={feature}>{feature}</li>)}</ul></div></article>)}</div></section>
        <section id="contact" className="book-page"><div className="page-inner"><div className="section-header"><div className="page-number"><span>04</span><i />Get in touch</div><div className="header-row"><h2>Let&apos;s build something.</h2><p>{portfolioData.contact.message}</p></div></div><div className="contact-grid"><div><p className="contact-lead">Good work starts with a clear conversation.</p><div className="contact-links"><a href={`mailto:${portfolioData.contact.email}`}><Mail size={17} />{portfolioData.contact.email}</a><a href={portfolioData.contact.github}><Link2 size={17} />GitHub</a><a href={portfolioData.contact.linkedin}><Link2 size={17} />LinkedIn</a></div></div><form onSubmit={(event) => event.preventDefault()}><div className="form-two"><label>Name<input required /></label><label>Email<input required type="email" /></label></div><label>Project type<select defaultValue=""><option value="" disabled>Select a service</option>{portfolioData.services.map((s) => <option key={s.id}>{s.name}</option>)}</select></label><label>Message<textarea required rows={4} /></label><button className="accent-button">Start a project <ArrowUpRight size={14} /></button></form></div></div></section>
      </div>
      <footer className="site-footer"><span>© 2026 JPX Solutions</span><span className="footer-center">Portfolio / Selected work &amp; services</span><button onClick={() => go('about')}>Back to top</button></footer>
    </main>
  )
}
